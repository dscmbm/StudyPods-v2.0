let allMusic = [
  {
    name: "Let me love you",
    artist: "DJ snake",
    img :"let me love you.jpeg",
    src: "let me love you.mpeg",
  },
  {
    name: "My heart's stereo",
    artist: "Gym Class Heroes",
    img: "my heart's stereo (2).jpeg",
    src: "my heart's stereo.mpeg",
    
  },
  {
    name: "Let me down slowly",
    artist: "Alec Benjamin",
    img: "let me down slowly.jpeg",
    src: "let me down slowly.mpeg",
  
  },
];
